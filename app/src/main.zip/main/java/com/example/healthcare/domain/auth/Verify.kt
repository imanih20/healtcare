package com.example.healthcare.domain.auth

data class Verify(
    val userId: String,
    val role: String
)