package com.example.healthcare.peresentation.auth.utils

enum class Role {
    Patient,Doctor,Admin,Unknown,
}