package com.example.healthcare.common

class NoNetworkException : Exception()