package com.example.healthcare.peresentation.common.utils

enum class DoctorAppointmentActions {
    Accept,
    Reject,
    Cancel
}