package com.example.healthcare.domain.profile.models

data class AdminProfile(
    val clinicID: String = "",
    val userID: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val phone: String = "",
    val country: String = "",
    val address: String = "",
    val postalCode: String = "",
    val profile: String = "",
    val role: String = "",
    val createDate: String = "",
    val clinicName: String = "",
    val clinicAddress: String = "",
    val clinicCountry: String = "",
    val clinicDescription: String = ""
)