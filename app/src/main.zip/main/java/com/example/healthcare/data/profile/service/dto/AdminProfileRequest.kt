package com.example.healthcare.data.profile.service.dto

import com.google.gson.annotations.SerializedName

data class AdminProfileRequest(
    @SerializedName("firstName") val firstName: String,
    @SerializedName("lastName") val lastName: String,
    @SerializedName("country") val country: String,
    @SerializedName("address") val address: String,
    @SerializedName("postalCode") val postalCode: String,
    @SerializedName("clinicName") val clinicName: String,
    @SerializedName("clinicAddress") val clinicAddress: String,
    @SerializedName("clinicCountry") val clinicCountry: String,
    @SerializedName("clinicDescription") val clinicDescription: String
)