package com.example.healthcare.common

const val BASE_URL = "https://healthcare-4s5i.onrender.com/api/" //todo: backend url