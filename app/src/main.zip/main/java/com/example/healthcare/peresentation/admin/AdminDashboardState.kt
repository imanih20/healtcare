package com.example.healthcare.peresentation.admin

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.healthcare.domain.profile.models.AdminProfile

@Composable
fun rememberAdminDashboardState(
) : AdminDashboardState {
    return remember {
        AdminDashboardState()
    }

}

class AdminDashboardState() {
    var firstName by mutableStateOf("")
    var lastName by mutableStateOf("")
    var address by mutableStateOf("")
    var country by mutableStateOf("")
    var postalCode by mutableStateOf("")
    var clinicCountry by mutableStateOf("")
    var clinicAddress by mutableStateOf("")
    var clinicName by mutableStateOf("")
    var clinicDescription by mutableStateOf("")

    fun init(adminProfile: AdminProfile){
        firstName = adminProfile.firstName
        lastName = adminProfile.lastName
        address = adminProfile.address
        country = adminProfile.country
        postalCode = adminProfile.postalCode
        clinicName = adminProfile.clinicName
        clinicAddress = adminProfile.clinicAddress
        clinicCountry = adminProfile.clinicCountry
        clinicDescription = adminProfile.clinicDescription

    }

    fun checkIfEdited(adminProfile: AdminProfile) : Boolean{
        return firstName != adminProfile.firstName || lastName != adminProfile.lastName ||
                address != adminProfile.address || country != adminProfile.country ||
                postalCode != adminProfile.postalCode || clinicCountry != adminProfile.clinicCountry ||
                clinicAddress != adminProfile.clinicAddress || clinicName != adminProfile.clinicName ||
                adminProfile.clinicDescription != clinicDescription
    }
}